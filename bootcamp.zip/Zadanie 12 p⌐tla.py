

a = 1  # przygotowanie
while a <= 100:  # warunek końca
    print(a**2)   # ciało pętli
    a += 1  # zmiana zmiennej sterującej

    
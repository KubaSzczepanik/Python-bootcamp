wiek = int (input('podaj rok urodzenia'))

if wiek <= 2000:
    print('jesteś pełnoletni')

else:
    print ('nie jestes pelnoletni')


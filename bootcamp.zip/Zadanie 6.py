
zmienna = int( input ('podaj licze'))
print(f'wieksza od 10: {zmienna > 10}')
print(f'Mniejsza równa 15:{zmienna <= 15}')
print(f' Podzielna przez 2: {zmienna % 2 ==0}')





print(' Witaj świecie!')

# int - liczba całkowita
a = 3

b = 3

ala_ma_kota = 90

#float - liczba ułamkowa
ulamek = 4.5
inne_opcje = 0.3
test = 3.



print(1/5)
print(0.2)

# błędy zaokrągleń
print (0.1 + 0.2)


# str - napisy
napis1 = "ala ma kota"
napis2 = ' ala ma kota'

print(napis1)
print(napis2)

# bool -wartości logiczne
prawda = True
falsz = False

a = ''
if a:
    print ( ' a zinterpretowane jako prawda')
else:
    print (' a zinterpretowane jako falsz')


# operator dodawania - +
# operator odejmowania -

a =10
h = 5
pole_trojkata = a * h/2
print(pole_trojkata)
pi = 3.14
r = 7
pole_kola =  pi*  r**2
print (pole_kola)
a = 3
b = 9
h = 6.5
pole_trapezu =  1/2*(a+b)*h
print(pole_trapezu)
r = 7/8
objetosc_kuli =4/3*3.14* (r) ** 3
print (objetosc_kuli)

imię = "kuba"
wzrost=  190

print ("imię", imię , wzrost,', a wzrost ')
print (f' {imię} {wzrost}')


#zadanie 4

cena = 10.0
waga = 2.5
należność = 25.0

# < wyrównaj do lewej
# ^ wyrównaj do środka
# > wyrównaj do prawej
print (f' {"cena":<10}  {cena:>10} \n '
       f'{"waga":<10} {waga:>10} \n '
       f'{"należność":<10} {cena * waga:>10}')


print(7^9)



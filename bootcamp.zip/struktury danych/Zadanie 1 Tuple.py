

a = (1,2,3,4,5,6,7,8,9,10)
#
print (a[1])
# przedostatni element
print(a[-2])
# elementy od trzeciego do siodmego(włącznie
print(a[2:7])
# co drugi element licząc od końca
print(a[::3])
#
print(a[-1])
print(a[::-2])

# co drugi element licząc od końca, startując od przedostatniego
print(a[-2::-2])



wysokość = int (input('wysokość'))
szerokość = int (input('szerokość'))
długość = int (input ('długość'))

v = wysokość * szerokość * długość
print (f' bryła o wymiarach {wysokość * szerokość * długość}')
print ('mieści 1 litr', {v>= 1000} )
print (v)

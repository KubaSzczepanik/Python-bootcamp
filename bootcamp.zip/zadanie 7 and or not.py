
# Napisz program sprawdzający czy podana przez uzytkownmika liczba jest podzielna przez 2,
#  podzielna przez 3 i wieksza od 10 lub jest to liczba7.


zmienna = int(input (' podaj licze'))
print(f'podzielna przez 2{zmienna % 2 == 0 and zmienna % 3 == 0 and zmienna >10 or zmienna == 7} ')

# liczba podzielna przez 2, podzielna przez 3 i wieksza od 10 lub rowna 7

# linijki najlepiej łamac na or

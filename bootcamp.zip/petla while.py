# przygotowane dane przed pętlą
# jak długo pętla ma się wykonywać, kiedy ma się skończyć ( nagłówek pętli)
# co pętla ma faktycznie robić ( ciało pętli)

a = 1 # przygotowanie
while a <10:  # nagłowek bloku konczy sie : # warunek końca (nagłówek)
    print(a)   # ciało pętli
    a = a + 1   # zmiana zmiennej sterującej

print ('po petli')

